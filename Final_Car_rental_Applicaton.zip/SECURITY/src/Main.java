import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // Force English numbers format
        Locale.setDefault(Locale.US);

        ArrayList<Car> cars = new ArrayList<>();
        RentalCalculator calculator = new RentalCalculator();

        try {
            // Add cars
            cars.add(new Car("Toyota", "RAV4", VehicleType.SUV, CarCategory.STANDARD, 30));
            cars.add(new Car("Toyota", "Camry", VehicleType.SEDAN, CarCategory.INTERMEDIATE, 32));
            cars.add(new Car("Ford", "F-150", VehicleType.TRUCK, CarCategory.STANDARD, 22));
            cars.add(new Car("Honda", "Civic Coupe", VehicleType.COUPE, CarCategory.ECONOMY, 31));
            cars.add(new Car("Toyota", "Prius", VehicleType.HYBRID, CarCategory.INTERMEDIATE, 52));
            cars.add(new Car("Honda", "CR-V", VehicleType.CROSSOVER, CarCategory.STANDARD, 28));
            cars.add(new Car("Honda", "Odyssey", VehicleType.VAN_MINIVAN, CarCategory.VAN, 22));

        } catch (IllegalArgumentException e) {
            // Fail Securely
            System.out.println("Error adding car: " + e.getMessage());
        }

        // Display cars
        System.out.println("Available Cars:\n");

        for (int i = 0; i < cars.size(); i++) {
            System.out.println("#" + (i + 1));
            cars.get(i).displayCar();
            System.out.println("--------------------------------------------------------------------");
        }

        if (cars.isEmpty()) {
            System.out.println("No cars available.");
            return;
        }

        Scanner scanner = new Scanner(System.in);

        int passengers = 0;
        int days = 0;
        double distance = 0;

        // Passengers input loop
        while (true) {
            try {
                System.out.print("Enter number of passengers: ");
                passengers = Integer.parseInt(scanner.nextLine());

                if (passengers <= 0) {
                    throw new IllegalArgumentException("Passengers must be greater than 0");
                }
                break;

            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        // Days input loop
        while (true) {
            try {
                System.out.print("Enter rental days: ");
                days = Integer.parseInt(scanner.nextLine());

                if (days <= 0) {
                    throw new IllegalArgumentException("Days must be greater than 0");
                }
                break;

            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        // Distance input loop
        while (true) {
            try {
                System.out.print("Enter expected mileage: ");
                distance = Double.parseDouble(scanner.nextLine());

                if (distance < 0) {
                    throw new IllegalArgumentException("Distance cannot be negative");
                }
                break;

            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        try {
            // Find best cars
            RentalQuote[] bestQuotes =
                    calculator.findBestCars(cars, days, distance, passengers);

            if (bestQuotes.length == 0) {
                System.out.println("No available car can fit your request.");
                return;
            }

            // Output
            System.out.println("\nBest Rental Option(s):");
            System.out.println("====================================================================");

            for (RentalQuote quote : bestQuotes) {

                System.out.println(quote.getCar().getMake() + " " +
                                   quote.getCar().getModel());

                System.out.println("Vehicle Type    : " +
                                   quote.getCar().getVehicleType());

                System.out.println("Category        : " +
                                   quote.getCar().getCategory());

                System.out.println("Comfort Level   : " +
                                   quote.getCar().getComfortLevel());

                System.out.println("Max Passengers  : " +
                                   quote.getCar().getMaxPassengers());

                System.out.printf("Rental Cost     : $%.2f%n",
                                  quote.getRentalCost());

                System.out.printf("Fuel Cost       : $%.2f%n",
                                  quote.getFuelCost());

                System.out.printf("Total Cost      : $%.2f%n",
                                  quote.getTotalCost());

                System.out.println("--------------------------------------------------------------------");
            }

        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
        }

        scanner.close();
    }
}